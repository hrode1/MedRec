var MedRec = artifacts.require("./MedRec.sol");
module.exports = function(deployer) {
   deployer.deploy(MedRec);
};
